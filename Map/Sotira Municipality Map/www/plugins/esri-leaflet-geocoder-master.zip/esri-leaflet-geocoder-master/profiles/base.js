import config from '../node_modules/esri-leaflet/profiles/base.js';

config.entry = 'src/EsriLeafletGeocoding.js';
config.moduleName = 'L.esri.Geocoding';

export default config;
